using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using PcKitIS.Services;
using PcKitIS.ViewModels;

namespace PcKitIS.Pages
{
    /// <summary>Графики LiveCharts и выгрузка отчёта в Word (ПР 8).</summary>
    public partial class ReportPage : Page
    {
        // Значения перечислений Word и Excel для вызовов через COM.
        private const int AlignLeft = 0;
        private const int AlignCenter = 1;
        private const int SingleLine = 1;
        private const int SaveAsDoc = 0;
        private const int SaveAsDocx = 12;
        private const int DoNotSaveChanges = 0;
        private const int PieChart = 5;
        private const int PlotByColumns = 2;
        private const int Lavender = 0xFAE6E6;

        public ReportPage()
        {
            InitializeComponent();
        }

        private async void WordReport_Click(object sender, RoutedEventArgs e)
        {
            if (!(DataContext is ReportViewModel reportViewModel)) return;

            var saveFileDialog = new SaveFileDialog
            {
                Filter = "Документ Word (*.docx)|*.docx|Документ Word 97-2003 (*.doc)|*.doc",
                DefaultExt = ".docx",
                FileName = $"Отчёт по продажам наборов {DateTime.Now:dd.MM.yyyy}"
            };

            if (saveFileDialog.ShowDialog() != true) return;

            var dialogService = ServiceContainer.Instance.Get<IDialogService>();
            plug.Visibility = Visibility.Visible;
            try
            {
                // Снимок данных страницы до запуска фонового потока.
                string path = saveFileDialog.FileName;
                var labels = reportViewModel.KitLabels.ToList();
                var values = reportViewModel.CountSoldValues.ToList();
                var popular = reportViewModel.PopularKit;
                string popularText = popular == null
                    ? "За выбранный период заказов нет."
                    : $"Самый популярный набор за период: {popular.Article} «{popular.Name}» ({popular.Category?.Name}), заказано: {reportViewModel.PopularKitCount} шт.";
                string imagePath = popular != null && !string.IsNullOrWhiteSpace(popular.Image)
                    ? Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, popular.Image))
                    : null;
                string summary = $"Период: с {reportViewModel.DateFrom:dd.MM.yyyy} по {reportViewModel.DateTo:dd.MM.yyyy}. Выручка за период: {reportViewModel.TotalRevenue:N0} ₽";

                await RunWordOnSta(() => ExportWord(path, summary, labels, values, popularText, imagePath));

                dialogService.ShowDialog("Отчёт успешно сформирован:\n" + path, "Отчёт", DialogType.InfoType);
            }
            catch (Exception ex)
            {
                dialogService.ShowDialog(
                    "Не удалось сформировать отчёт.\n" + ex.Message, "Ошибка", DialogType.ErrorType);
            }
            finally
            {
                plug.Visibility = Visibility.Hidden;
            }
        }

        private static Task RunWordOnSta(Action export)
        {
            var completion = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            var wordThread = new Thread(() =>
            {
                try
                {
                    export();
                    completion.SetResult(true);
                }
                catch (Exception ex)
                {
                    completion.SetException(ex);
                }
            }) { IsBackground = true };
            wordThread.SetApartmentState(ApartmentState.STA);
            wordThread.Start();
            return completion.Task;
        }

        private static void ExportWord(string path, string summary, IReadOnlyList<string> labels,
            IReadOnlyList<int> values, string popularText, string imagePath)
        {
            // Позднее связывание обращается к установленному Word через COM.
            // Оно позволяет обойтись без сборки office.dll.
            Type wordType = Type.GetTypeFromProgID("Word.Application");
            if (wordType == null)
                throw new InvalidOperationException("Для выгрузки установите или восстановите Microsoft Word.");

            dynamic word = Activator.CreateInstance(wordType);
            try
            {
                word.Visible = false;
                word.DisplayAlerts = 0;
                dynamic document = word.Documents.Add();
                try
                {
                    dynamic heading = document.Paragraphs.Add();
                    heading.Range.Text = "Отчёт по продажам наборов для сборки ПК «ПК-Бокс»";
                    heading.Range.Font.Name = "Times New Roman";
                    heading.Range.Font.Size = 16;
                    heading.Range.Font.Bold = 1;
                    heading.Alignment = AlignCenter;
                    heading.Range.InsertParagraphAfter();

                    dynamic period = document.Paragraphs.Add();
                    period.Range.Text = summary;
                    period.Range.Font.Size = 14;
                    period.Range.Font.Bold = 0;
                    period.Alignment = AlignLeft;
                    period.Range.InsertParagraphAfter();

                    dynamic paragraph = document.Paragraphs.Add();
                    paragraph.Range.Font.Size = 12;
                    dynamic table = document.Tables.Add(paragraph.Range, labels.Count + 1, 3);
                    table.Borders.InsideLineStyle = SingleLine;
                    table.Borders.OutsideLineStyle = SingleLine;
                    table.Rows[1].Range.Bold = 1;
                    table.Rows[1].Shading.BackgroundPatternColor = Lavender;
                    table.Cell(1, 1).Range.Text = "№";
                    table.Cell(1, 2).Range.Text = "Набор";
                    table.Cell(1, 3).Range.Text = "Заказано, шт.";
                    for (int i = 0; i < labels.Count; i++)
                    {
                        int row = i + 2;
                        table.Cell(row, 1).Range.Text = (i + 1).ToString();
                        table.Cell(row, 2).Range.Text = labels[i];
                        table.Cell(row, 3).Range.Text = values[i].ToString();
                    }

                    if (values.Any(value => value > 0))
                    {
                        document.Content.InsertParagraphAfter();
                        paragraph = document.Paragraphs.Add();
                        paragraph.Alignment = AlignCenter;
                        dynamic chart = document.InlineShapes.AddChart2(-1, PieChart, paragraph.Range).Chart;
                        chart.ChartData.Activate();
                        dynamic workbook = chart.ChartData.Workbook;
                        try
                        {
                            dynamic sheet = workbook.Worksheets[1];
                            sheet.UsedRange.ClearContents();
                            sheet.Cells[1, 1].Value2 = "Набор";
                            sheet.Cells[1, 2].Value2 = "Заказано, шт.";
                            int row = 2;
                            for (int i = 0; i < labels.Count; i++)
                            {
                                if (values[i] <= 0) continue;
                                sheet.Cells[row, 1].Value2 = labels[i];
                                sheet.Cells[row, 2].Value2 = values[i];
                                row++;
                            }

                            string sheetName = ((string)sheet.Name).Replace("'", "''");
                            chart.SetSourceData($"='{sheetName}'!$A$1:$B${row - 1}", PlotByColumns);
                            chart.HasTitle = true;
                            chart.ChartTitle.Text = "Доля заказов по наборам";
                        }
                        finally
                        {
                            workbook.Close(true);
                        }
                    }

                    document.Content.InsertParagraphAfter();
                    paragraph = document.Paragraphs.Add();
                    paragraph.Alignment = AlignLeft;
                    paragraph.Range.Font.Size = 14;
                    paragraph.Range.Text = popularText;
                    paragraph.Range.InsertParagraphAfter();

                    if (imagePath != null && File.Exists(imagePath))
                    {
                        paragraph = document.Paragraphs.Add();
                        paragraph.Alignment = AlignCenter;
                        dynamic picture = document.InlineShapes.AddPicture(
                            imagePath, false, true, paragraph.Range);
                        picture.Width = 240;
                        picture.Height = 180;
                    }

                    bool legacyFormat = Path.GetExtension(path).Equals(".doc", StringComparison.OrdinalIgnoreCase);
                    document.SaveAs2(path, legacyFormat ? SaveAsDoc : SaveAsDocx);
                }
                finally
                {
                    document.Close(DoNotSaveChanges);
                }
            }
            finally
            {
                word.Quit(DoNotSaveChanges);
            }
        }
    }
}
